package com.baesystems.webtestapplication.service;

import java.net.URL;

import com.baesystems.webtestapplication.model.Project;

public class ProjectService {

    public URL getProjectServer(Project project) {
        try {
            return new URL(project.getServer());
        } catch (Exception e) {
            return null;
        }
    }

}
